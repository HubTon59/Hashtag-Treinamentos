const numero1 = 27;
const numero2 = 23.25;
const numero3 = -40;
const total = numero1 + numero2 + numero3;

console.log(total);
