const primeiraVariavel = 'essa é a minha variavel';

