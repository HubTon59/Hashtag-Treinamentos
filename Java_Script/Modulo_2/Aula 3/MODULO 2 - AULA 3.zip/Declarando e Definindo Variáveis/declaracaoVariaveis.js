let variavelNova = 'valorDessaVariavel';
variavelNova = 'novoValor';

let ultimaVariavelDaAula;

ultimaVariavelDaAula = 'finalmente coloquei um valor nessa variável';

console.log(variavelNova);
console.log(ultimaVariavelDaAula);